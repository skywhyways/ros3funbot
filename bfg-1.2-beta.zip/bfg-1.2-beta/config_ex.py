API_TOKEN = ''

admin = []
start_money = 10000

bot_name = 'BFG'
chat = 't.me/copybfg'
chanell = 't.me/copybfg'
admin_username = '@copybfg'
bot_username = 'bfgcopybot'

chat_log = 0
cleaning = 60