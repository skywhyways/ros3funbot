API_TOKEN = '8385763893:AAG6cEDVMAbWjHsd_i18DT-3o0I31tFJPtc'

admin = [6261639658]
start_money = 50000

bot_name = 'Ros3Fun'
chat = 'https://t.me/+WjJxUc0xg9E3NjAy'
chanell = 'https://t.me/ros3channel'
admin_username = '@beautifulros3'
bot_username = 'bfgcopybot'

chat_log = 0
cleaning = 60